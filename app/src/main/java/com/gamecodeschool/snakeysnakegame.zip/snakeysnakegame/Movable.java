package com.gamecodeschool.snakeysnakegame;

public interface Movable { //interface for move method`
    void move();
}
